import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import dearpygui.dearpygui as dgp 

# ----------------- Save and Load -----------------

def save_data():
    with open("showroom.txt", "w") as file:
        file.write(f"LIMIT={limit}\n")

        file.write("CARS\n")
        for car, price in Cars.items():
            file.write(f"{car},{price}\n")

        file.write("SALES\n")
        for car, price in Sales.items():
            file.write(f"{car},{price}\n")

def load_data():
    global Cars, Sales, limit
    Cars = {}
    Sales = {}
    limit = 0
    mode = None

    try:
        with open("showroom.txt", "r") as file:
            for line in file:
                line = line.strip()
                if line.startswith("LIMIT="):
                    limit = int(line.split("=")[1])
                elif line == "CARS":
                    mode = "cars"
                elif line == "SALES":
                    mode = "sales"
                elif line and mode == "cars":
                    car, price = line.split(",")
                    Cars[car] = int(price)
                elif line and mode == "sales":
                    car, price = line.split(",")
                    Sales[car] = int(price)
    except FileNotFoundError:
        pass

# ----------------- Visualization -----------------

def visualize():
    if not Cars:
        return "No cars available to visualize"
    df = pd.DataFrame(list(Cars.items()), columns=["Car","Price"])
    plt.figure(figsize=(12,6))
    sns.barplot(x="Price", y="Car", data=df, palette="Blues_r")  
    plt.xlabel("Price (Rs)")
    plt.ylabel("Car Names")
    plt.title("Showroom Car Prices")
    plt.tight_layout()
    plt.show()
    return df

def visualize_sales():
    if not Sales:
        return "No sales available to visualize"
    df = pd.DataFrame(list(Sales.items()), columns=["Car","Price"])
    plt.figure(figsize=(12,6))
    sns.barplot(x="Price", y="Car", data=df, palette="Greens_r")  
    plt.xlabel("Price (Rs)")
    plt.ylabel("Car Names")
    plt.title("Sold Cars and Their Prices")
    plt.tight_layout()
    plt.show()
    return df

# ----------------- Functionalities -----------------

def view_collection():
    if not Cars:
        return "No cars available"
    df = pd.DataFrame(list(Cars.items()), columns=["Car","Price"])
    return df

def add_car(cars_to_add):
    """cars_to_add = list of tuples [('CarName', price), ...]"""
    global limit
    for car_name, price in cars_to_add:
        if len(Cars) >= limit:
            return "Storage full! Upgrade limit."
        Cars[car_name] = price
    save_data()
    return Cars

def upgrade_limit(new_limit):
    global limit
    if new_limit > 0:
        limit += new_limit
        save_data()
        return f"Limit upgraded to {limit}"
    return "Limit must be > 0"

def remove_car(car_name):
    if car_name in Cars:
        del Cars[car_name]
        save_data()
        return Cars
    return "Car not found"

def average_price():
    if Cars:
        total = sum(Cars.values())
        return total / len(Cars)
    return "No cars available"

def sell_car(car_name):
    if car_name in Cars:
        sold_price = Cars[car_name]
        Sales[car_name] = sold_price
        del Cars[car_name]
        save_data()
        return f"{car_name} sold for Rs {sold_price}"
    return "Car not found"

def net_worth():
    return sum(Cars.values())

def search_car(car_name):
    for car in Cars:
        if car.lower() == car_name.lower():
            return f"{car} : Rs {Cars[car]}"
    return "Car not found"

def net_profit():
    return sum(Sales.values())

def pure_profit():
    total_profit = 0
    tax_rate = 0.20
    other_fees = 10000
    details = {}
    for car, price in Sales.items():
        profit = price - (price * tax_rate) - other_fees
        details[car] = profit
        total_profit += profit
    return details, total_profit

# ----------------- Initialize -----------------

Cars = {}
Sales = {}
limit = 0
load_data()
