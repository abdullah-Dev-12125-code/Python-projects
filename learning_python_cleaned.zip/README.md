# Learning Python 🐍

This repository contains my complete Python learning journey,
from basics to advanced mini projects and experiments.

Folder structure:
01_basics
02_calculators
03_loops_patterns
04_data_analysis
05_mini_projects
06_school_projects
07_fun_experiments
08_quizzes

Author: Abdullah
