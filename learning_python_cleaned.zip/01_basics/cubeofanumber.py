num = int(input("Enter your number here: "))
root = num * num * num
print("The cube of", num, "is", root)

