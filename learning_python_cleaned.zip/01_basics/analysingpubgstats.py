import pandas as pd
import matplotlib.pyplot as plt 

pd.read_csv("fake_pubg_20000_matches.csv")