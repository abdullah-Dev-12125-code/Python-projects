import qrcode 

img = qrcode.make(r"https://youtu.be/6usRtfzyLa8?si=P420uc-mpQI4c7tq")
type(img)
img.save("PicofQR.png")