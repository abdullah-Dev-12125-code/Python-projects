total = 0
for i in range(1,11):
    total +=i
print(total)

