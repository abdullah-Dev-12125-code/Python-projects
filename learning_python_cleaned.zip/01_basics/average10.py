# ages = []
# total = 0

# for i in range(10):
#     age = int(input(f"Enter age of player {i+1}: "))
#     ages.append(age)
#     total += age

# average = total / 10
# print("\nAges entered:", ages)
# print("Average age of players:", average)



sum = 0
i = 1

while i <= 10:
    sum = sum + i
    i = i + 1
print("The sum = ",sum)