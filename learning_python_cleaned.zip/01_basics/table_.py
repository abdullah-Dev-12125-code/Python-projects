a = int(input("enter the value here: "))
b = int(input("enter the end value here: "))

for i in range (1, b+1):
    print(a*i)

