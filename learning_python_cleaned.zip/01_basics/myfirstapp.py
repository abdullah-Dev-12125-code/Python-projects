regions = ["NYC", "LON", "DEL", "PAR", "TOK", "KHI"]

accounts = []
branch = 10
customer = 1

for i in range(1000):
    region = regions[i % len(regions)]           # cycle through regions
    branch_code = str(branch).zfill(2)           # 2‑digit branch
    customer_num = str(customer).zfill(5)        # 5‑digit customer number

    account = region + branch_code + customer_num
    accounts.append(account)

    branch += 1
    customer += 1

    if branch > 99:      # restart branch after 99
        branch = 10

print("Total:", len(accounts))
 
