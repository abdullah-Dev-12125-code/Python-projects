number = int(input("Enter the year you want to calculate,here: "))
if(number % 4 == 0):
    print("it's a leap year")
else:
    print("It's not a leap year")