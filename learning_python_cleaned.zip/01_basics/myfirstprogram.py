a = int(input("Enter the number: "))
b = int(input("Enter the of times multiply: "))

for i in range(1, b+1):
    print(a*i)

