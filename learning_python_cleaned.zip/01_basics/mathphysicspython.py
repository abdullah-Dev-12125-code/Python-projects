import numpy as np

# N = int(input("Enter a number here: "))

# for i in range(1,N+1):
#     if i % 2== 0:
#         print(i,"Is Even")
#     else:
#         print(i,"Is Odd")

# Matrix1 = np.array([[1,  2,  3],
#                     [2,  5,  6],
#                     [7, -1,  2],])


# Matrix2 = np.array([[3,  2, -8],
#                     [2,  7, -7],
#                     [7, -1,  2],])




# Sums = Matrix1 + Matrix2
# product = Matrix1 @ Matrix2
# diffrence = Matrix1 - Matrix2


# print("Sum:", Sums)
# print("product", product)
# print("diffrence", diffrence)

# Speed
Time = float(input("Enter Time in Seconds: "))
Distance = float(input("Enter speed in meters: "))
v = Distance/Time

print("Speed(M/S) =",v)
print("Speed(Km/h)=",v * 3.6)

# Acceleration

final_Velocity = int(input("Enter Vf here: "))
Initial_Velocity = int(input("Enter Vi here: "))
Times = float(input("Enter Time in seconds: "))

Acceleration = final_Velocity - Initial_Velocity / Times

print("Acceleration",Acceleration)


