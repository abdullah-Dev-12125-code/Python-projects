import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def save_data():
    with open("showroom.txt", "w") as file:
        file.write(f"LIMIT={limit}\n")

        file.write("CARS\n")
        for car, price in Cars.items():
            file.write(f"{car},{price}\n")

        file.write("SALES\n")
        for car, price in Sales.items():
            file.write(f"{car},{price}\n")


def load_data():
    global Cars, Sales, limit
    Cars = {}
    Sales = {}
    limit = 0
    mode = None

    try:
        with open("showroom.txt", "r") as file:
            for line in file:
                line = line.strip()

                if line.startswith("LIMIT="):
                    limit = int(line.split("=")[1])

                elif line == "CARS":
                    mode = "cars"

                elif line == "SALES":
                    mode = "sales"

                elif line and mode == "cars":
                    car, price = line.split(",")
                    Cars[car] = int(price)

                elif line and mode == "sales":
                    car, price = line.split(",")
                    Sales[car] = int(price)

    except FileNotFoundError:
        pass



def visualize():
    """Visualize showroom cars with prices."""
    if not Cars:
        print("No cars available to visualize")
        return

    df = pd.DataFrame(list(Cars.items()), columns=["Car","Price"])
    print("\n", df ,"\n")

    plt.figure(figsize=(12,6))
    sns.barplot(x="Price", y="Car", data=df, palette="Blues_r")  
    plt.xlabel("Price (Rs)")
    plt.ylabel("Car Names")
    plt.title("Showroom Car Prices")
    plt.tight_layout()
    plt.show()


def visualize_sales():
    """Visualize sales cars with prices."""
    if not Sales:
        print("No sales available to visualize")
        return

    df = pd.DataFrame(list(Sales.items()), columns=["Car","Price"])
    print("\n", df ,"\n")

    plt.figure(figsize=(12,6))
    sns.barplot(x="Price", y="Car", data=df, palette="Greens_r")  # Horizontal bar chart
    plt.xlabel("Price (Rs)")
    plt.ylabel("Car Names")
    plt.title("Sold Cars and Their Prices")
    plt.tight_layout()
    plt.show()


Cars = {}
Sales = {}
limit = 0
load_data()  


while True:
    print("\n1.View Collection")
    print("2.Add car")
    print("3.Upgrade limit")
    print("4.Remove car")
    print("5.Visualize sales")
    print("6.Average Sales")
    print("7.Sale Car")
    print("8.Net worth Of showroom")
    print("9.Search")
    print("10.Net Profit")
    print("11.Pure Profit")
    print("12.Exit\n")

    try:
        choice = int(input("Choose one of them for desired task: "))
        
        if choice == 1:
            if not Cars:
                print("No cars available")
            else:
               df = pd.DataFrame(list(Cars.items()), columns=["Car","Price"])
               print("\nYour Showroom Collection:\n")
               print(df)
          
        elif choice == 2:
            if limit == 0:
                while True:
                    Set_limit = int(input("\nEnter How much cars you can store: "))
                    if Set_limit == 0:
                        print("Greater then 0")
                    else:
                        limit += Set_limit 
                        save_data()
                        break

            print(f"\nYou can add {limit} cars.\n")
            
            while len(Cars) < limit:
                Cars_ADD = input(f"Enter name of car ('stop' If dont have anymore): ")
                if Cars_ADD.lower() == 'stop':
                    if Cars:
                        print("Updated",Cars)
                    break
                price = int(input("Enter price of car: "))
                if Cars_ADD in Cars:
                    print("ALready added")
                    Cars[Cars_ADD] = price
                save_data()
                
                
                print(f"\n{Cars_ADD} has been added to the list")
                print(f"You can add {limit - len(Cars)} more cars.")
                print(f"\n{Cars}\n")
                
               
            if len(Cars) >= limit:
                print("Storage is full! Upgrade limit to add more cars.")

        elif choice == 3:
            print("Current limit is",limit)
            Set_LImits = int(input("Enter the limit of cars you can store: "))
            if Set_LImits == 0:
                print("Set limit > 0")
            else:
                limit += Set_LImits
                save_data()
                print(f"The limit has been set to {limit}")    

        elif choice == 4:
            print("\nHere is your list remove what you want\n")
            print(Cars)
            Remove_Cars = input("\nEnter name of Car you want to remove: ")
            if Remove_Cars in Cars:
                print(f"{Remove_Cars} has been removed")
                del Cars[Remove_Cars]
                print(f"Updated list\n",Cars)
                save_data()
                
        elif choice == 5:
            sales_or_showroom = int(input("Visualize (1) Showroom or (2) Sales?: "))
            if sales_or_showroom == 1:
                visualize()
            elif sales_or_showroom == 2:
                visualize_sales()   
            

        elif choice == 6:
            if Cars:
                total = sum(Cars.values())
                averages = total / len(Cars)
                print(f"Average Price in your showroom is {averages:.2f}") 
            else:
                print("No cars available to calculate average")

        elif choice == 7:
                try:
                    print("Change the price to sold ")
                    Cases = input("To set price to sold(S): ").lower()
                    if Cases == 's':
                        Item = input("Enter name of car you want to sell: ")

                        if Item in Cars:
                            sold_price = Cars[Item]  
                            Sales[Item] = sold_price    
                            del Cars[Item] 
                            save_data()
                            print(f"{Item} has been sold for Rs {sold_price}")
                        else:
                            print("Car not found!")
                     
                except (ValueError,TabError):
                    print("Enter Price in numeric")
                except Exception as e:
                    print("Unexpected error!!",e)

        elif choice == 8:
            net_worth = sum(price for price in Cars.values() if isinstance(price,int))
            print(f"Net worth of showroom is {net_worth}")
        
        elif choice == 9:
            search = input("Search here: ").lower()

            for car in Cars:
                if car.lower() == search:
                    print(f"\nThe |{car} : RS {Cars[car]}| is available")
                    break
            else:
                print("No car with that name")


                
        elif choice == 10:
            Net_profit = 0
            for prices in Sales:
                Net_profit = sum(Sales.values())
            print(f"Net profit is : RS {Net_profit}")
                
        elif choice == 11:
            pure_profit = 0
            tax_rate = 0.20
            other_fees = 10000

            for car, price in Sales.items():
                profit_after_tax = price - (price * tax_rate) - other_fees
                pure_profit += profit_after_tax
                print(f"{car} profit after tax & fees: Rs {profit_after_tax}")

            print(f"\nTotal Pure Profit: Rs {pure_profit}")
        
        elif choice == 12:
            exit()
    
    except(ValueError):
        print("Enter a Numeric number(1.5.7.10)!!")


