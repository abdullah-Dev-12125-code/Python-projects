import math
def root(square):
    if num >0:
        square = math.sqrt(num)

num = int(input("Enter num here: "))
o = root()
print(F"square root of {num} is {o}")

