year =int(input("Enter a year: "))
if (year % 4 == 0):
    print("Its a leap year.")
else:
    print("its not an leap year.")

