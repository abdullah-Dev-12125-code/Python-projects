# import sys
# print(sys.version)

# print("This will be printed")

# print("hello,world!")

# z = 2 + 15
# print(z)

# a = ("Enter your name")
# print(type(a))

# print(type(17))

# print(type(10.5761))

# print(type("Abdullah"))

# print(type(False))

# print(int(2.0))

# print(int(True))
# print(int(False))

# n = 0 / 2
# print(type(n))

# type("hello" == "world")

# b = ("1001")
# print(type(b))
# print(int(b))

# x = 45 + 70 + 78 + 43
# print(x)
# print(x / 60)

# name = ("The body guard")
# print(name[-10])
# print(name[0])

# print(len("The bodyguard"))

# print(name[0:5])
# print(name[4:9])
# print(name[::2])

# print(name + "abdullah")
# print(3 * name)

# r = ("the house is full of darkness")
# print(r)

# print(r.find('th'))
# print(r.find('full of'))

# import re

# j = ("Abdullah")

# pattern = r"ull"
# result = re.search(pattern, j)
# if result:
#     print("Match Found!")
# else:
#     print("Match not found!")

# mult = ("4" + "abdullah")
# print(mult)

# lists = ["abdullah", "name", "pygame", "stamp", "data", "harder"]
# lists.append("abd")
# lists.append(465)
# lists.append(876)
# lists.append("jack")
# lists.append('marlo')
# print(lists)

# p = [['cats', 'are'], ['life']]

# print(p[1][0])
# print(p)

# string = input("Enter element here(Space-Seperated):")

# lst = string.split()
# print("The lsit is: ", lst)

# po = int(input("Enter how many elements: "))
# string = list(map(int, input("Enter the elements: ").strip().split()))[:po]

# print("The list is:", string)

# po = int(input("Enter how many elements: "))
# string = list(map(int, input("Enter the elements: ").strip().split()))[:po]

# print("The list is:", string)



# listtest = ["Abdullah","Hussain","Gamer","content","creator"]
# print(listtest)
# listtest.reverse()
# print(listtest)

# listtest.remove("Gamer")
# print(listtest)
# for i in range (1,3):
#     listtest.pop(i)
# print(listtest)


# firsttuple = ("Rust","Go","swift","Binary")
# print(firsttuple)
# i,j,k,l = firsttuple
# print(i)
# print(j)
# print(k)
# print(l)


# tuple = ("Fia", "Cia", "Isi", "Isis")
# tuple1 = ("Who", "UN", "WTC", "CLP")

# tuple3 = tuple + tuple1

# for i in range(1,6):
#     tuple.remove(i)
# print(tuple)

# print(tuple3)
# del tuple
# print(tuple)


# def name(fname, mname, lname="ui"):
#     print("Hello,", fname, mname, lname)
 
# name("Peter", "Quill",)

# num = 7
# def fun(num):
#     for nums in range(2,num):
#         return nums
    

book = ["Abdullah","Hussain"]
identify = input(" Enter books name: ")

if identify in book:
    print("This book is in the library")

