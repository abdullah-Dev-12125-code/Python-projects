D = 5
for i in range(1, D + 1):
    print(" " * (D - i) + "*" * (2 * i - 1))
