a = int(input("How many times: "))
b = input("What do you want: ")
for i in range(a):
    print(b)
