import random

Basic_message = []
Secret_lang = []

Message = "Abdullah"
lenght = len(Message)
if lenght >=3:
    Message = Message[1:] + Message[0]
    Message = random
print(Message)