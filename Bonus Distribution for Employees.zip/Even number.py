while True:
    num = int(input("Enter the number here: "))
    if num %2 == 0:
        print("Even")
    else:
        print("Odd")